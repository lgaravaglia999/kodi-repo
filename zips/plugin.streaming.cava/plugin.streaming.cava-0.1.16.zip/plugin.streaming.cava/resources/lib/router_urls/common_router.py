from resources.lib.controllers import MainController

URLS = [
    {'play': MainController.play}
]
