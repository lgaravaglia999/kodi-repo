# plugin.streaming.cava

### Info
Un addon di Kodi permette di vedere in streaming film e/o serie tv.


### Installazione
Per installare e avere aggiornamenti in automatico su questo add-on dovrai aggiungere una nuova sorgente su kodi.

Per farlo basta andare in `settings -> file manager -> add source` e inserire dove richiesto questo percorso https://lgaravaglia999.github.io/kodi-repo/repo/.

Una volta fatto vai in `settings -> Add-ons` clicca su installa add-on da file zip selezionando la sorgente che hai appena aggiunto e installa i seguenti file zip:

- repository.cava-x.x.zip
- script.module.urlresolver-x.x.xx.zip (potrebbe metterci anche un minutino ad installare questo modulo)

Infine, una volta installati con successo entrambi gli zip, vai in `settings -> Add-ons -> install from repository -> video add-ons`.